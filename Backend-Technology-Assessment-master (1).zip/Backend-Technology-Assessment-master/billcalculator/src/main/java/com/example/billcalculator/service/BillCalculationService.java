package com.example.billcalculator.service;

import com.example.billcalculator.model.Bill;

public interface BillCalculationService {
    double calculatePayableAmount(Bill bill);
}
