package com.example.billcalculator.model;

import java.util.Map;

public class CurrencyResponse {

    private Map<String, Double> rates;

    public Map<String, Double> getRates() {
        return rates;
    }

    public void setRates(Map<String, Double> rates) {
        this.rates = rates;
    }
}
