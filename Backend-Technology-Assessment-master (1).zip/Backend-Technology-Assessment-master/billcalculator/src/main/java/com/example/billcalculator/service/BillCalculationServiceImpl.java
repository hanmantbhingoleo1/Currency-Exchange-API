package com.example.billcalculator.service;

import com.example.billcalculator.model.Bill;
import com.example.billcalculator.model.CurrencyResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class BillCalculationServiceImpl implements BillCalculationService {

    @Value("${currency.api.url}")
    private String apiUrl;

    @Value("${currency.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate;

    public BillCalculationServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public double calculatePayableAmount(Bill bill) {
        // Apply discounts
        double discount = applyDiscounts(bill);
        double amountAfterDiscounts = bill.getTotalAmount() - discount;

        // Print values for debugging
        System.out.println("Discount applied: " + discount);
        System.out.println("Amount after discount: " + amountAfterDiscounts);

        // Convert to target currency using the exchange rate
        double exchangeRate = getExchangeRate(bill.getOriginalCurrency(), bill.getTargetCurrency());
        System.out.println("Exchange rate from " + bill.getOriginalCurrency() + " to " + bill.getTargetCurrency() + ": " + exchangeRate);

        // Calculate final payable amount in target currency
        double finalAmount = amountAfterDiscounts * exchangeRate;

        // Print the final payable amount
        System.out.println("Final payable amount in " + bill.getTargetCurrency() + ": " + finalAmount);

        return finalAmount;
    }

    private double applyDiscounts(Bill bill) {
        double discount = 0;

        // Apply percentage-based discounts based on user type
        if (bill.getUserType().equalsIgnoreCase("employee")) {
            discount = bill.getTotalAmount() * 0.30;
            System.out.println("Employee discount: " + discount);
        } else if (bill.getUserType().equalsIgnoreCase("affiliate")) {
            discount = bill.getTotalAmount() * 0.10;
            System.out.println("Affiliate discount: " + discount);
        } else if (bill.getCustomerTenure() > 2) {
            discount = bill.getTotalAmount() * 0.05;
            System.out.println("Customer tenure discount: " + discount);
        }

        // Apply $5 discount for every $100
        double additionalDiscount = (bill.getTotalAmount() / 100) * 5;
        discount += additionalDiscount;
        System.out.println("Additional $5 discount for every $100: " + additionalDiscount);

        // Exclude groceries from percentage-based discounts
        double groceryAmount = bill.getGroceryAmount();
        if (groceryAmount > 0) {
            double groceryDiscountAdjustment = groceryAmount * 0.30; // Adjusting for groceries in case of employee discount
            discount -= groceryDiscountAdjustment;
            System.out.println("Grocery discount adjustment: " + groceryDiscountAdjustment);
        }

        System.out.println("Total discount applied: " + discount);
        return discount;
    }

    private double getExchangeRate(String baseCurrency, String targetCurrency) {
        // Build the URL dynamically with the provided baseCurrency and API key
        String url = UriComponentsBuilder.fromHttpUrl(apiUrl)
                .buildAndExpand(baseCurrency, apiKey)
                .toUriString();

        // Print the URL for debugging
        System.out.println("Fetching exchange rate with URL: " + url);

        // Make the API call and get the response as a CurrencyResponse object
        CurrencyResponse response = restTemplate.getForObject(url, CurrencyResponse.class);

        // Extract the exchange rate for the target currency
        if (response != null && response.getRates() != null) {
            double exchangeRate = response.getRates().getOrDefault(targetCurrency, 0.0);
            System.out.println("Exchange rate retrieved: " + exchangeRate);
            return exchangeRate;
        } else {
            throw new RuntimeException("Failed to get exchange rate.");
        }
    }
}
